from .base import UiAbstract

__all__ = ["UiAbstract"]
